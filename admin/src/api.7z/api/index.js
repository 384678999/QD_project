import fun from './modules/fun'
import leition from './modules/leition'

const api={
     leition,
     fun
};

export default api;
