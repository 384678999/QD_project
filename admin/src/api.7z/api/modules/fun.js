import { get, post } from './init'

export default {

    //图片上传
    uploadImg: (params) => post('usercentre/uploadImg', params),  //参数 uid upfile
    // 个人资料
    getPersonal: (params) => get('uacuser/getPersonal', params),  //参数 uid
    // 修改个人资料
    updateUser: (params) => post('uacuser/updateUser', params),  //参数 uid username email
    // 修改密码
    changepassword: (params) => post('uacuser/changepassword ', params),  //参数 oldpassword newpassword uid
    // 用户列表
    uacUsersList: (params) => get('user/getUserList', params),  //参数 start:1 limit:2
    // 用户列表新增
    insertUser: (params) => post('uacuser/insertUser', params),  //参数 username email password
    //获取对应用户角色
    role: (params) => get('user/role', params),  //参数  appId:3
    // 删除用户
    deleteUser: (params) => get('uacuser/deleteUser', params),  //参数 uid
    // 解锁
    updateUnlock: (params) => post('uacuser/updateUnlock ', params),  //参数 uid
    // 锁定
    updateStatus: (params) => post('uacuser/updateStatus', params),  //参数 uid
    // 批量删除用户
    deleteUserlist: (params) => get('uacuser/deleteUserlist', params),  //参数 uid[ ]
    // 批量解锁
    updateUnlockList: (params) => get('uacuser/updateUnlockList', params),  //参数 uid[ ]
    // 批量锁定
    deleteStatusList: (params) => get('uacuser/deleteStatusList', params),  //参数 uid[ ]
    // 获取用户锁定列表
    getUserStatusList: (params) => get('uacuser/getUserStatusList', params),  //参数 uid[ ]



    Login: (params) => post('login', params),
    //图片上传
    uploadImg: (params) => post('upload', params),
    //用户管理
    usersList: (params) => get('users', params),
    usersStore: (params) => post('users_store', params),
    usersShow: (params) => get('users_info', params),
    usersDelete: (params) => get('users_delete', params),
    usersLock: (params) => get('users_lock', params),
    usersPwd: (params) => post('users_pwd', params),
    usersPermissions: (params) => get('users_permissions', params),
    //角色管理
    rolesList: (params) => get('roles', params),
    rolesAll: () => get('roles'),
    rolesShow: (params) => get('roles_info', params),
    rolesStore: (params) => post('roles_store', params),
    rolesDelete: (params) => get('roles_delete', params),
    //权限管理
    permissionsList: (params) => get('permissions', params),
    getPermissionsAll: (params) => get('permissions_all', params),
    permissionsShow: (params) => get('permissions_info', params),
    permissionsStore: (params) => post('permissions_store', params),
    permissionsDelete: (params) => get('permissions_delete', params),
    //日志
    logsList: (params) => get('logs', params),
    logsStore: (params) => post('logs_store', params),
    logsUsersList: (params) => get('logs_users', params),
    //文章
    articleList: (params) => get('article', params),
    articleShow: (params) => get('article_info', params),
    articleStore: (params) => post('article_store', params),
    articleDelete: (params) => get('article_delete', params),
    //文章分类
    article_cateList: (params) => get('article_cate', params),
    article_cateShow: (params) => get('article_cate_info', params),
    article_cateStore: (params) => post('article_cate_store', params),
    article_cateDelete: (params) => get('article_cate_delete', params),
};
