<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
import home from "../view/home";

export default {
  data() {
    return {};
  }
};
</script>

<style>
</style>
