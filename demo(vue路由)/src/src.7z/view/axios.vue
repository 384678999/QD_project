<template>
  <div>
    <h1>{{mag}}</h1>
  </div>
</template>

<script>
import { getPersonal } from "@/request/api.js"; // 导入我们的api接口
export default {
  data() {
    return {
      mag: "axios"
    };
  }
};
</script>

<style>
</style>