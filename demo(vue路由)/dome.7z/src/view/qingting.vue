<template>
  <div>
    <h1>{{mag}}</h1>
  </div>
</template>

<script>
export default {
  data() {
    return {
      mag: "Hello Word 情哥哥"
    };
  }
};
</script>

<style>
</style>