const error = [
  // {
  //   path: '/404',
  //   meta: {
  //     title: '页面不存在',
  //     requiresAuth: false
  //   },
  //   component: resolve => require(['@/module/error/404'], resolve)
  // },
  // {
  //   path: '/noAuth',
  //   meta: {
  //     title: '无权限',
  //     requiresAuth: false
  //   },
  //   component: resolve => require(['@/module/error/noAuth'], resolve)
  // },
  // {
  //   path: '*',
  //   redirect: '/404'
  // }
]
export default error;